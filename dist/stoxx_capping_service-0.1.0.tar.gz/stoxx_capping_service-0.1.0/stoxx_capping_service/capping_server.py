"""Python implementation of the index capping"""
from concurrent import futures
import logging
import pandas as pd
import grpc
import capping_pb2
import capping_pb2_grpc


class CappingServicer(capping_pb2_grpc.CappingServicer):
    """Provides methods that implement functionality of capping server."""

    def __mcaps_to_data_frame(self, mcaps):
        rows = list()
        for mcap in mcaps:
            d = {"mcap": mcap.mcap, "c1": mcap.components[0]}

            # if we are doing multi component capping, add the additional components
            for i in range(1, len(mcap.components)):
                d["c" + str(i + 1)] = mcap.components[i]
            rows.append(d)

        return pd.DataFrame(rows)

    def __cap(self, request):
        df_mcaps = self.__mcaps_to_data_frame(mcaps=request.mcaps)

        for i_component_index, methodology_data in enumerate(request.methodologyDatas):
            print(
                "methodology: "
                + capping_pb2.Methodology.Name(methodology_data.methodology)
            )
            if methodology_data.methodology == capping_pb2.Methodology_Exposure:
                df_parent_mcaps = self.__mcaps_to_data_frame(mcaps=request.parent_mcaps)
                df_final = self.__cap_exposure(
                    df_parent_mcaps=df_parent_mcaps, df_mcaps=df_mcaps
                )
                continue

            if i_component_index > 0:
                df_merged = df_mcaps.merge(df_grouped, on="c1", how="inner")[
                    ["c1", "c2", "weight_plus_residual"]
                ]
                df_merged.rename(columns={"weight_plus_residual": "mcap"}, inplace=True)
                df_merged.drop_duplicates(
                    subset="c" + str(i_component_index), inplace=True
                )
                df_grouped = (
                    df_merged.groupby("c" + str(i_component_index + 1))["mcap"]
                    .sum()
                    .reset_index()
                    .sort_values("mcap", ascending=False)
                )

            else:
                df_grouped = (
                    df_mcaps.groupby("c" + str(i_component_index + 1))["mcap"]
                    .sum()
                    .reset_index()
                    .sort_values("mcap", ascending=False)
                )

            if len(methodology_data.limitInfos) == 0:
                cap_limit = 0
            else:
                limit_info = methodology_data.limitInfos[0]
                cap_limit = limit_info.limit

            if methodology_data.methodology == capping_pb2.Methodology_Ladder:
                df_group_list = list()
                for n, limit in enumerate(methodology_data.limitInfos):
                    df_grouped = self.__cap_component(
                        df_grouped=df_grouped,
                        cap_limit=limit.limit,
                        is_first_iteration=True,
                        exclude_nth_rows_from_cap=None if n == 0 else n,
                    )
                    df_grouped["orig_pct"] = df_grouped["pct"]
                    df_group_list.append(df_grouped.copy())
                df_grouped = self.__flatten_results_for_ladder(df_group_list)
                return df_grouped
            else:
                df_grouped = self.__cap_component(
                    df_grouped=df_grouped,
                    cap_limit=cap_limit,
                    is_first_iteration=True,
                )

            cols = list(
                df_mcaps.columns if i_component_index == 0 else df_final.columns
            )
            cols.append("factor")
            cols[0] = "mcap_x"

            if i_component_index == 0:
                df_final = df_mcaps.merge(
                    df_grouped, on="c" + str(i_component_index + 1), how="inner"
                )[cols]
            else:
                df_final = df_final.merge(
                    df_grouped, on="c" + str(i_component_index + 1), how="inner"
                )[cols]

            df_final.rename(
                columns={
                    "mcap_x": "mcap",
                    "factor": "c" + str(i_component_index + 1) + "_factor",
                },
                inplace=True,
            )
        df_final["factor"] = df_final.apply(
            lambda x: self.__multiply_factors(
                num_components=(i_component_index + 1), df_row=x
            ),
            axis=1,
        )
        return df_final

    def __multiply_factors(self, num_components: int, df_row: pd.Series):
        factor = df_row["c1_factor"]

        if num_components == 1:
            return factor

        for i in range(2, (num_components + 1)):
            factor *= df_row["c" + str(i) + "_factor"]

        return factor

    def __flatten_results_for_ladder(self, list_dfs: list):
        df_root = list_dfs[0]
        for idx, df in enumerate(list_dfs):
            if idx > 0:
                df_root = df_root.merge(df, on="c1", how="inner")[
                    ["c1", "factor_x", "factor_y"]
                ]
                df_root["factor"] = df_root.apply(
                    lambda x: x["factor_x"] * x["factor_y"], axis=1
                )
                df_root.drop(["factor_x", "factor_y"], axis=1, inplace=True)
            print("")
        return df_root

    def __cap_exposure(self, df_parent_mcaps: pd.DataFrame, df_mcaps: pd.DataFrame):
        df_parent_grouped = df_parent_mcaps.groupby("c1")["mcap"].sum().reset_index()
        df_parent_grouped_sum = round(df_parent_grouped["mcap"].sum(), 15)
        df_parent_grouped["pct"] = df_parent_grouped.apply(
            lambda x: x["mcap"] / df_parent_grouped_sum, axis=1
        )

        df_grouped = df_mcaps.groupby("c1")["mcap"].sum().reset_index()
        df_grouped_sum = round(df_grouped["mcap"].sum(), 15)
        df_grouped["pct"] = df_grouped.apply(
            lambda x: x["mcap"] / df_grouped_sum, axis=1
        )

        df_final = df_parent_grouped.merge(df_grouped, on="c1", how="left")[
            ["c1", "pct_x", "pct_y"]
        ]
        df_final.rename(
            columns={"pct_x": "pct_parent", "pct_y": "pct_child"}, inplace=True
        )
        df_final["factor"] = df_final.apply(
            lambda x: x["pct_parent"] / x["pct_child"], axis=1
        )

        has_missing_component = df_final["factor"].isna().any()
        if not has_missing_component:
            return df_final

        df_final["child_pct_capped_mcaps"] = df_final.apply(
            lambda x: x["pct_child"] * x["factor"], axis=1
        )

        sum_child_pct = round(df_final["child_pct_capped_mcaps"].sum(), 15)

        df_final["missing_weight"] = df_final.apply(
            lambda x: (1 - sum_child_pct)
            * (x["child_pct_capped_mcaps"] / sum_child_pct),
            axis=1,
        )

        df_final["new_child_tw"] = df_final.apply(
            lambda x: x["child_pct_capped_mcaps"] + x["missing_weight"],
            axis=1,
        )

        df_final.rename(columns={"factor": "old_factor"}, inplace=True)

        df_final["factor"] = df_final.apply(
            lambda x: x["new_child_tw"] / x["pct_child"],
            axis=1,
        )

        return df_final

    def __cap_component(
        self,
        df_grouped: pd.DataFrame,
        cap_limit: float,
        is_first_iteration: bool,
        sum_residuals: float = None,
        sum_truncated_weight_under_cap_limit: float = None,
        exclude_nth_rows_from_cap: int = None,
    ):
        if is_first_iteration and exclude_nth_rows_from_cap is None:
            # the rounding line stops a testcase where sum = 1.0000000000000002 from failing
            component_sum = round(df_grouped["mcap"].sum(), 15)
            df_grouped["orig_pct"] = df_grouped.apply(
                lambda x: x["mcap"] / component_sum, axis=1
            )
            df_grouped["pct"] = df_grouped["orig_pct"]
        else:
            df_grouped.drop(
                columns=[
                    "apply_cap",
                    "residuals",
                    "truncated_weight",
                    "underweight_pct",
                    "spread_residual",
                    "weight_plus_residual",
                    "factor",
                ],
                inplace=True,
            )

        df_grouped["apply_cap"] = True

        if exclude_nth_rows_from_cap is not None:
            # Update the column values for the first n rows
            df_grouped.loc[
                df_grouped.index[:exclude_nth_rows_from_cap], "apply_cap"
            ] = False

        df_grouped["residuals"] = df_grouped.apply(
            lambda x: x["pct"] - cap_limit
            if x["pct"] > cap_limit and x["apply_cap"] == True
            else 0,
            axis=1,
        )
        if sum_residuals is None:
            sum_residuals = round(df_grouped["residuals"].sum(), 15)

        df_grouped["truncated_weight"] = df_grouped.apply(
            lambda x: x["pct"] - x["residuals"], axis=1
        )

        if sum_truncated_weight_under_cap_limit is None:
            sum_truncated_weight_under_cap_limit = round(
                df_grouped[df_grouped["truncated_weight"] < cap_limit][
                    "truncated_weight"
                ].sum(),
                15,
            )

        df_grouped["underweight_pct"] = df_grouped.apply(
            lambda x: x["truncated_weight"] / sum_truncated_weight_under_cap_limit
            if x["truncated_weight"] < cap_limit
            else 0,
            axis=1,
        )

        df_grouped["spread_residual"] = df_grouped.apply(
            lambda x: x["underweight_pct"] * sum_residuals, axis=1
        )

        df_grouped["weight_plus_residual"] = df_grouped.apply(
            lambda x: x["truncated_weight"] + x["spread_residual"], axis=1
        )

        df_grouped["weight_plus_residual"] = df_grouped.apply(
            lambda x: x["truncated_weight"] + x["spread_residual"], axis=1
        )
        df_grouped["factor"] = df_grouped.apply(
            lambda x: x["weight_plus_residual"] / x["orig_pct"],
            axis=1,
        )

        any_overweight_component = (
            (df_grouped["weight_plus_residual"] > cap_limit) & df_grouped["apply_cap"]
        ).any()

        df_grouped["pct"] = df_grouped["weight_plus_residual"]

        if any_overweight_component:
            return self.__cap_component(
                df_grouped=df_grouped,
                cap_limit=cap_limit,
                is_first_iteration=False,
                sum_residuals=sum_residuals,
                sum_truncated_weight_under_cap_limit=sum_truncated_weight_under_cap_limit,
                exclude_nth_rows_from_cap=exclude_nth_rows_from_cap,
            )
        else:
            return df_grouped

    def Cap(self, request, context):
        # print("methodology is: " + capping_pb2.Methodology.Name(request.methodology))

        df_factors = self.__cap(request=request)

        cap_result = capping_pb2.CapResult()
        factors = list(df_factors["factor"])
        max_factor = max(factors)

        for factor in factors:
            if request.mcapDecreasingFactors:
                cap_result.CappingFactor.append(round(factor / max_factor, 15))
            else:
                cap_result.CappingFactor.append(round(factor, 15))

        return cap_result


def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    capping_pb2_grpc.add_CappingServicer_to_server(CappingServicer(), server)
    server.add_insecure_port("[::]:50051")
    server.start()
    server.wait_for_termination()


if __name__ == "__main__":
    logging.basicConfig()
    serve()
