import pathlib, sys
sys.path.append(str(pathlib.Path(__file__).parent))